import axios from "axios";
/*
https://my-json-server.typicode.com
/juangomez2345/online_json_db/products
*/

const loadProducts = () => {
  /*
  const products = [
    { id: 1, name: "Dell", price: 100 },
    { id: 2, name: "Lenovo", price: 200 },
    { id: 3, name: "Gateway", price: 300 }
  ];
  return {
    type: "REPLACE_PRODUCTS",
    products: products
  };
  */

  return async dispatch => {
    const response = await axios.get(
      "https://my-json-server.typicode.com/juangomez2345/online_json_db/products"
    );
    console.log(response.data);
    dispatch({
      type: "REPLACE_PRODUCTS",
      products: response.data
    });
  };
};

const addToCart = product => {
  return {
    type: "ADD_TO_CART",
    product: product
  };
};

const removeFromCart = product => {
  return {
    type: "REMOVE_FROM_CART",
    product: product
  };
};

export { loadProducts, addToCart, removeFromCart };
