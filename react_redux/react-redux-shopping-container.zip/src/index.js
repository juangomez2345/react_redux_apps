import React, { Component } from "react";
import ReactDOM from "react-dom";

import ProductList from "./components/ProductList";
import ShoppingCart from "./components/ShoppingCart";

import store from "./store";
import { Provider } from "react-redux";
import { loadProducts } from "./actionCreators";

import "./styles.css";

class App extends Component {
  render() {
    return (
      <div id="iduserItem">
        <table>
          <tbody>
            <tr>
              <td>
                Products
                <ProductList />
              </td>
            </tr>
            <tr>
              <td>
                <p />
              </td>
            </tr>
            <tr>
              <td>
                Shopping Car
                <ShoppingCart />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

store.dispatch(loadProducts());

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById("root")
);
