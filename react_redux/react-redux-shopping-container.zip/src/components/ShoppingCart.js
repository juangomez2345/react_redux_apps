import React from "react";
import { removeFromCart } from "../actionCreators";
import { connect } from "react-redux";

const styles = {
  footer: {
    fontWeight: "bold",
    width: "100px"
  },
  table: {
    border: "1px solid #F2F2F2"
  },
  table_td: {
    width: "100px"
  }
};

//se convierte a componente funcional
const ShoppingCart = props => {
  return (
    <table style={styles.table}>
      <tbody>
        {props.cart.map((product, index) => (
          <tr key={index}>
            <td style={styles.table_td}>{product.name}</td>
            <td style={styles.table_td}>${product.price}</td>
            <td style={styles.table_td}>
              <button onClick={() => props.removeFromCart(product)}>del</button>
            </td>
          </tr>
        ))}
      </tbody>
      <tfoot>
        <tr>
          <td colSpan="4" style={styles.footer}>
            Total: $
            {props.cart.reduce((sum, product) => sum + product.price, 0)}
          </td>
        </tr>
      </tfoot>
    </table>
  );
};

const mapStateToProps = state => {
  return {
    cart: state.cart
  };
};

const mapDispatchToProps = dispatch => {
  return {
    removeFromCart(product) {
      console.log("mapDispatchToProps.removeFromCart: " + product.name);
      dispatch(removeFromCart(product));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ShoppingCart);
