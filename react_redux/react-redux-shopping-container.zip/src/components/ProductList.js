import React from "react";
import { addToCart } from "../actionCreators";
import { connect } from "react-redux";

const styles = {
  table: {
    border: "1px solid #F2F2F2"
  },
  table_td: {
    width: "100px"
  }
};

//se convierte a componente funcional
const ProductList = props => {
  return (
    <div id="productlistid">
      {props.products.map(product => (
        <div key={product.id}>
          <div id="productId">
            <table style={styles.table}>
              <tbody>
                <tr>
                  <td style={styles.table_td}>{product.name}</td>
                  <td style={styles.table_td}>{product.price}</td>
                  <td style={styles.table_td}>
                    <button onClick={() => props.addToCart(product)}>
                      add
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
};

const mapStateToProps = state => {
  return {
    products: state.products
  };
};

const mapDispatchToProps = dispatch => {
  return {
    addToCart(product) {
      console.log("mapDispatchToProps.addToCart: " + product.name);
      dispatch(addToCart(product));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ProductList);
