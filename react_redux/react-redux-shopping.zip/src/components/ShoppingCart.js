import React, { Component } from "react";
import store from "../store";
import { removeFromCart } from "../actionCreators";

const styles = {
  footer: {
    fontWeight: "bold",
    width: "100px"
  },
  table: {
    border: "1px solid #F2F2F2"
  },
  table_td: {
    width: "100px"
  }
};

class ShoppingCart extends Component {
  constructor() {
    super();
    this.removeFromCart = this.removeFromCart.bind(this);

    this.state = {
      cart: []
    };

    store.subscribe(() => {
      this.setState({
        cart: store.getState().cart
      });
    });
  }

  render() {
    return (
      <table style={styles.table}>
        <tbody>
          {this.state.cart.map((product, index) => (
            <tr key={index}>
              <td style={styles.table_td}>{product.name}</td>
              <td style={styles.table_td}>${product.price}</td>
              <td style={styles.table_td}>
                <button onClick={() => this.removeFromCart(product)}>
                  del
                </button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan="4" style={styles.footer}>
              Total: $
              {this.state.cart.reduce((sum, product) => sum + product.price, 0)}
            </td>
          </tr>
        </tfoot>
      </table>
    );
  }

  removeFromCart(product) {
    console.log(product.name);
    store.dispatch(removeFromCart(product));
  }
}

export default ShoppingCart;
