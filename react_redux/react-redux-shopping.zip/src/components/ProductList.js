import React, { Component } from "react";
import store from "../store";
import { addToCart } from "../actionCreators";

const styles = {
  table: {
    border: "1px solid #F2F2F2"
  },
  table_td: {
    width: "100px"
  }
};

class ProductList extends Component {
  constructor() {
    super();
    this.addToCart = this.addToCart.bind(this);

    /*this.state = {
      products: [
        { id: 1, name: "Dell", price: 100 },
        { id: 2, name: "Vaio", price: 200 },
        { id: 3, name: "Gateway", price: 300 }
      ]
    };*/

    this.state = {
      products: store.getState().products
    };
  }

  render() {
    return (
      <div id="productlistid">
        {this.state.products.map(product => (
          <div key={product.id}>
            <div id="productId">
              <table style={styles.table}>
                <tbody>
                  <tr>
                    <td style={styles.table_td}>{product.name}</td>
                    <td style={styles.table_td}>{product.price}</td>
                    <td style={styles.table_td}>
                      <button onClick={() => this.addToCart(product)}>
                        add
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    );
  }

  addToCart(product) {
    console.log(product.name);
    store.dispatch(addToCart(product));
  }
}

export default ProductList;
