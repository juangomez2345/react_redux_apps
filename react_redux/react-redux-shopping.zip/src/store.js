import { createStore } from "redux";

const reducer = (state, action) => {
  if (action.type === "ADD_TO_CART") {
    return {
      ...state,
      cart: state.cart.concat(action.product)
    };
  } else if (action.type === "REMOVE_FROM_CART") {
    return {
      ...state,
      cart: state.cart.filter(product => product.id !== action.product.id)
    };
  }

  return state;
};

const initialState = {
  cart: [],
  products: [
    { id: 1, name: "Dell", price: 100 },
    { id: 2, name: "Vaio", price: 200 },
    { id: 3, name: "Gateway", price: 300 }
  ]
};

export default createStore(reducer, initialState);
