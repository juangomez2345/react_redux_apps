import React, { Component } from "react";
import ReactDOM from "react-dom";

import ProductList from "./components/ProductList";
import ShoppingCart from "./components/ShoppingCart";

import "./styles.css";

class App extends Component {
  render() {
    return (
      <div id="iduserItem" className="App">
        <table>
          <tbody>
            <tr>
              <td>
                <label>Products</label>
                <ProductList />
              </td>
            </tr>
            <tr>
              <td>
                <p />
              </td>
            </tr>
            <tr>
              <td>
                <label>Shopping Car</label>
                <ShoppingCart />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
