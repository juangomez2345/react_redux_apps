import React, { Component } from "react";
import ReactDOM from "react-dom";
import { SingleReducer } from "./single_reducer";
import { CombineReducer } from "./combine_reducer";

import "./styles.css";

class App extends Component {
  render() {
    return (
      <div id="iduserItem">
        <table>
          <tbody>
            <tr>
              <td>Redux</td>
            </tr>
            <tr>
              <td>{CombineReducer}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

ReactDOM.render(<App />, document.getElementById("root"));
