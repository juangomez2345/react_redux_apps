import { createStore, combineReducers } from "redux";

console.clear();

//--------- actions
const createTransaction = (id = "", name = "", description = "") => {
  return {
    type: "ADD_TRANSACTION",
    transaction: {
      id,
      name,
      description
    }
  };
};

const removeTransaction = (id = "") => {
  return {
    type: "REMOVE_TRANSACTION",
    transaction: {
      id
    }
  };
};

//--------- reduceres
const transactionReducer = (transactionList = [], action) => {
  switch (action.type) {
    case "ADD_TRANSACTION":
      return [...transactionList, action.transaction];
    case "REMOVE_TRANSACTION":
      return transactionList.filter(
        transaction => transaction.id !== action.transaction.id
      );
    default:
      return transactionList;
  }
};

const transactionHistoryReducer = (transactionHistoryList = [], action) => {
  if (action.type === "ADD_TRANSACTION") {
    return [...transactionHistoryList, action.transaction];
  }
  return transactionHistoryList;
};

const allReducers = combineReducers({
  transactionReducer,
  transactionHistoryReducer
});

let store = createStore(allReducers);

store.dispatch(createTransaction(1, "SPEI", "Same Bank"));
store.dispatch(createTransaction(2, "SPEI", "Bank To Bank"));
store.dispatch(createTransaction(3, "Transfer", "Personal Acounts"));

store.dispatch(removeTransaction(1));
store.dispatch(removeTransaction(2));

console.log(store.getState());
