import { createStore } from "redux";

console.clear();

//--------- actions
const addProduct = product => {
  return {
    type: "ADD_PRODUCT",
    product
  };
};

const removeProduct = product => {
  return {
    type: "REMOVE_PRODUCT",
    product
  };
};

//--------- reducer
const reducer = (productList = [], action) => {
  switch (action.type) {
    case "ADD_PRODUCT":
      return [...productList, action.product];
    case "REMOVE_PRODUCT":
      return productList.filter(product => product.id !== action.product.id);
    default:
      return productList;
  }
};

//--------- execute actions
let store = createStore(reducer);

store.dispatch(addProduct({ id: 1, name: "Dell", price: 100 }));
store.dispatch(addProduct({ id: 2, name: "Lenovo", price: 200 }));
store.dispatch(addProduct({ id: 3, name: "Gateway", price: 300 }));

//store.dispatch(removeProduct({ id: 1, name: "Dell", price: 100  }));
store.dispatch(removeProduct({ id: 2, name: "Lenovo", price: 200 }));
//store.dispatch(removeProduct({ id: 3, name: "Gateway", price: 300 }));

console.log(store.getState());
